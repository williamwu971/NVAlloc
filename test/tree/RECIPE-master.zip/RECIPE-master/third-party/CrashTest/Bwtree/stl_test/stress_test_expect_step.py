

sum = 0.0
M = 10000000
for i in range(1, M):
    sum += (1.0 / float(i))
    
print sum