#include <string>

namespace idx { namespace utils {

    const std::string g_GIT_SHA1 = "@GIT_SHA1@";

} }