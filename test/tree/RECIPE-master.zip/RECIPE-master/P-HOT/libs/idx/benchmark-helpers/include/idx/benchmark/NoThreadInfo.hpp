#ifndef __IDX__BENCHMARK__NO_THREAD_INFO__
#define __IDX__BENCHMARK__NO_THREAD_INFO__

namespace idx { namespace benchmark {

struct NoThreadInfo {
};

}}

#endif